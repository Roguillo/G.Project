export const config = {
    "host" : "shopcompdb.cu32gyy8exmx.us-east-1.rds.amazonaws.com",
    "user" : "administrator",
    "password" : "shopComp:pass",
    "database" : "shopComp"
}