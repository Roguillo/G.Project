import { config } from './config.mjs'
import mysql from 'mysql'

/**
 * event is JSON of the form:
  
  { 
    "username" : "username",
    "password" : "password"
  }
  
 */

// Specify credentials
var pool = mysql.createPool({
  host:     config.host,
  user:     config.user,
  password: config.password,
  database: config.database
})

export const handler = async (event) => {
  let result
  let code


  // Checks if a username exists
  let checkExists = (username) => {
    let username = String(username)

    return new Promise((resolve, reject) => {
      const checkQuery = "SELECT * FROM Shoppers WHERE username = ?"
      pool.query(checkQuery, [username], (error, rows) => {
        if (error) {
          reject(new Error("Database error: " + error.sqlMessage))
        } else {
          resolve(rows && rows.length > 0)
        }
      })
    })
  }


  let validateCredentials = (username, password) => {
    let username = String(username)
    let password = String(password)

    return new Promise((resolve, reject) => {
      const checkQuery = "SELECT shopperID FROM Shoppers WHERE (username, password) = (?, ?)"
      pool.query(checkQuery, [username, password], (error, shopperID) => {
        if (error) {
          reject(new Error("Database error: " + error.sqlMessage))
        } else {
          resolve(shopperID)
        }
      })
    })
  }


  let generateLoginToken = (loginToken, shopperID) => {
    return new Promise((resolve, reject) => {
      const insertQuery = "INSERT INTO LoginTokens (loginToken, shopperID) VALUES (?, ?)"
      pool.query(insertQuery, [loginToken, shopperID], (error) => {
        if (error) {
          reject(new Error("Database error: " + error.sqlMessage))
        } else {
          resolve(true)
        }
      })
    })
  }


  try {
    // Define JSON inputs as variables
    const username = event.username
    const password = event.password


    // Checks if inputs are valid, throws an error if invalid
    if (!username || !password) {
      throw Error("All fields must have at least one character")
    }

    // Checks if the username exists in the DB
    const exists = await checkExists(username)
    if (!exists) {
      throw Error("Account with username: " + username + " doesn't exist")
    }

    // Check if the username and password match, return error if not
    const shopperCredentials = await validateCredentials(username)
    if (!shopperCredentials) {
      throw Error("Incorrect password")
    }

    
    // Creates login token if all previous test cases pass
    loginToken = "loginToken" + crypto.randomUUID()
    generateLoginToken(loginToken, shopperCredentials)

    // Returns 200 and success result
    result = { "body" : "Successfully logged into " + username,
               "loginToken" : loginToken }
    code = 200

  } catch (error) {
    result = { error: error.message }
    code = 400
  }


  const response = {
    statusCode: code,
    body: JSON.stringify(result)
  }

  return response
}