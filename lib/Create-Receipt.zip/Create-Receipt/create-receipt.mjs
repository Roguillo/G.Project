import mysql from 'mysql2'

var pool;

export const handler = async (event) => {
  //if(loginToken && !(receipt already exists));

  //create with chain, store, date(day, month, year)

  package = {
    chain: event.chain,
    store: event.store,
    date: event.date
  }

  const response = {
    statusCode: 200,
    body      : JSON.stringify('package')
  };

  return(response);
};
